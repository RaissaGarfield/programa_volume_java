public class Paralelepipedo {
    public static double calcularParalelepipedo(double comprimento,double largura, double altura) {
        double volume = 0.0;
        volume =  comprimento * largura * altura ;
        return volume;
    }
}
