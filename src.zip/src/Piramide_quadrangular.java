public class Piramide_quadrangular {
    public static double calcularPiramideQuadrangular(double lado, double altura) {
        double volume = 0.0;
        volume =  ( lado * lado * altura ) / 3.0;
        return volume;
    }
}
